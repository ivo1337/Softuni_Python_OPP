from project.movie import Movie
import unittest

class TestMovie(unittest.TestCase):
    def setUp(self) -> None:
        self.movie = Movie("Test", 2020, 5.5)

    def test_init(self):
        self.assertEqual(self.movie.name, "Test")
        self.assertEqual(self.movie.year, 2020)
        self.assertEqual(self.movie.rating, 5.5)
        self.assertEqual(self.movie.actors, [])

    def test_name_setter(self):
        with self.assertRaises(ValueError) as ex:
            self.movie.name = ""
        self.assertEqual(str(ex.exception), "Name cannot be an empty string!")

    def test_year_setter(self):
        with self.assertRaises(ValueError) as ex:
            self.movie.year = 1886
        self.assertEqual(str(ex.exception), "Year is not valid!")

    def test_add_actor(self):
        self.movie.add_actor("Actor")
        self.assertEqual(self.movie.actors, ["Actor"])
        self.assertEqual(self.movie.add_actor("Actor"), "Actor is already added in the list of actors!")

    def test_gt(self):
        other_movie = Movie("Other", 2020, 6.5)
        self.assertEqual(self.movie.__gt__(other_movie), '"Other" is better than "Test"')
        self.assertEqual(other_movie.__gt__(self.movie), '"Other" is better than "Test"')

    def test_repr(self):
        self.assertEqual(self.movie.__repr__(), "Name: Test\nYear of Release: 2020\nRating: 5.50\nCast: ")


if __name__ == "__main__":
    unittest.main()