from project.beverage import Beverage

class HotBeverage(Beverage):
    pass