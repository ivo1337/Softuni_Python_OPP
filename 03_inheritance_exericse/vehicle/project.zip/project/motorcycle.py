from project.car import Car

class Motorcycle(Car):
    pass